const express = require('express');
const mongoose = require('mongoose');
const client = require('prom-client');
const app = express();
const register = new client.Registry();

// Middleware to parse JSON bodies
app.use(express.json());

// Prometheus counter metric
const bookApiRequests = new client.Counter({
  name: 'book_api_requests_total',
  help: 'Total number of requests to the Book API',
  labelNames: ['method'],
});
register.registerMetric(bookApiRequests);

// MongoDB connection
const uri = 'mongodb+srv://it21473524:vaued@cluster0.niyhtwa.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB Atlas'))
  .catch(err => console.error('MongoDB connection error:', err));

// Define Book schema
const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  year: Number,
});
const Book = mongoose.model('Book', bookSchema);

// Create a new book
app.post('/books', async (req, res) => {
  try {
    const newBook = new Book(req.body);
    await newBook.save();
    bookApiRequests.inc({ method: 'POST' });
    res.status(201).json(newBook);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all books
app.get('/books', async (req, res) => {
  try {
    const books = await Book.find();
    bookApiRequests.inc({ method: 'GET' });
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get a book by ID
app.get('/books/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    bookApiRequests.inc({ method: 'GET' });
    res.status(200).json(book);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update a book by ID
app.put('/books/:id', async (req, res) => {
  try {
    const updatedBook = await Book.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedBook) return res.status(404).json({ message: 'Book not found' });
    bookApiRequests.inc({ method: 'PUT' });
    res.status(200).json(updatedBook);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete a book by ID
app.delete('/books/:id', async (req, res) => {
  try {
    const deletedBook = await Book.findByIdAndDelete(req.params.id);
    if (!deletedBook) return res.status(404).json({ message: 'Book not found' });
    bookApiRequests.inc({ method: 'DELETE' });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Metrics endpoint for Prometheus
app.get('/metrics', async (req, res) => {
  res.setHeader('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Book API is running on http://localhost:${PORT}`);
});
